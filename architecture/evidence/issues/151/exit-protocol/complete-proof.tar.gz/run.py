import argparse, hashlib, importlib.metadata, io, json, os, pathlib, socket, subprocess, sys, tarfile, tempfile, time, urllib.request

parser=argparse.ArgumentParser(description='Pinned RF deployment-order protocol proof; only /tmp output, no DB/provider/browser.')
parser.add_argument('--repo',type=pathlib.Path,default=pathlib.Path.cwd())
parser.add_argument('--output',type=pathlib.Path)
args=parser.parse_args()
ROOT=args.repo.resolve()
OUT=(args.output or pathlib.Path(tempfile.mkdtemp(prefix='talli-151-rollout-protocol-'))).resolve()
if OUT==ROOT or ROOT in OUT.parents:raise SystemExit('Proof output must be outside the repository')
if pathlib.Path('/tmp').resolve() not in OUT.parents:raise SystemExit('Proof output must be under /tmp')
OUT.mkdir(parents=True,exist_ok=True)
HARNESS=pathlib.Path(__file__).resolve().parent
REVISIONS={'old':'91b178c281bcc5fb887a6257d2f72e380199f3e6','new':'dd1a7dba8192746f5e882d5b119d895bf7730ce1'}
manifest={'revisions':REVISIONS,'files':{},'python':sys.version,'limits':'Real loopback HTTP with exact extracted application/client/transport sources and existing CoordinatorSession local fakes. No DB, browser, provider or UI hydration.'}
manifest['harness']={name:hashlib.sha256((HARNESS/name).read_bytes()).hexdigest() for name in ['run.py','server.py','proof.mjs']}
manifest['dependencies']={name:importlib.metadata.version(name) for name in ['fastapi','uvicorn','pytest']}
for version,revision in REVISIONS.items():
    assert subprocess.check_output(['git','rev-parse',revision+'^{commit}'],cwd=ROOT,text=True).strip()==revision
    dest=OUT/version;dest.mkdir(exist_ok=True)
    source_test='test_rf1086_compatibility.py' if version=='old' else 'test_shareholder_register_filing_production.py'
    transport='legacy-rf1086' if version=='old' else 'shareholder-register-filing'
    paths=['apps/backend/src',f'apps/backend/tests/{source_test}','packages/talli-api-client','apps/web/package.json','apps/web/lib/backend-configuration.ts',f'apps/web/features/{transport}/transport.ts','apps/web/app/actions.ts']
    data=subprocess.check_output(['git','archive',revision,*paths],cwd=ROOT)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(dest,filter='data')
    for p in sorted(dest.rglob('*')):
        if p.is_file():manifest['files'][f'{version}/{p.relative_to(dest)}']=hashlib.sha256(p.read_bytes()).hexdigest()
    link=dest/'node_modules/@talli/talli-api-client';link.parent.mkdir(parents=True,exist_ok=True)
    if not link.exists():link.symlink_to(dest/'packages/talli-api-client',target_is_directory=True)
(OUT/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
processes=[];logs=[];ports={}
try:
    for version in REVISIONS:
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        ports[version]=port
        log=(OUT/f'{version}-server.log').open('w');logs.append(log)
        env={'PATH':os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','PROOF_ROOT':str(OUT),'PYTHONPATH':str(OUT/version/'apps/backend/src')+':'+str(OUT/version/'apps/backend/tests')}
        p=subprocess.Popen([sys.executable,'-B',str(HARNESS/'server.py'),version,str(port)],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT);processes.append(p)
        for attempt in range(100):
            if p.poll() is not None:raise RuntimeError(f'{version} server exited; see its log')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/__proof/state',timeout=.3) as r:json.load(r)
                break
            except OSError:time.sleep(.1)
        else:raise RuntimeError(f'{version} server unavailable')
    env={'PATH':os.environ['PATH'],'PROOF_ROOT':str(OUT),'REPO_ROOT':str(ROOT),'OLD_PORT':str(ports['old']),'NEW_PORT':str(ports['new'])}
    result=subprocess.run(['node','--experimental-strip-types',str(HARNESS/'proof.mjs')],cwd=OUT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (OUT/'transcript.log').write_text(result.stdout)
    print(result.stdout,end='');print('node_exit=',result.returncode);print('artifacts=',OUT)
    if result.returncode:raise SystemExit(result.returncode)
finally:
    for p in processes:
        p.terminate()
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:p.kill();p.wait()
    for log in logs:log.close()

