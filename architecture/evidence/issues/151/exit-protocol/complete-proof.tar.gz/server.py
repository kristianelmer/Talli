import importlib, inspect, json, os, pathlib, socket, sys
from dataclasses import asdict
import uvicorn
from fastapi import Request

version,port=sys.argv[1:]
module=importlib.import_module('test_rf1086_compatibility' if version=='old' else 'test_shareholder_register_filing_production')
from talli_backend.main import create_app
if version=='old':
    from talli_backend.compatibility.rf1086_authority_workflow import LegacyRf1086AuthenticationError as AuthenticationError
else:
    from talli_backend.application.shareholder_register_filing_session import ShareholderRegisterFilingAuthenticationError as AuthenticationError
assert str(pathlib.Path(os.environ['PROOF_ROOT'])/version) in inspect.getfile(create_app)

class Sessions:
    def __init__(self):self.reset()
    def reset(self,mode='normal'):
        self.value=module.CoordinatorSession();self.tokens=[];self.requests=[]
        if mode=='unknown':self.value.mutation_authority.main_error=module.Rf1086AuthorityError('RF1086_NETWORK_ERROR',retryable=True)
        if mode=='token_failure':self.value.failure='mutation_token'
    async def session(self,token):
        self.tokens.append(token)
        if token!='local-owner':raise AuthenticationError()
        return self.value
sessions=Sessions()
app=create_app(**{('legacy_rf1086_session_factory' if version=='old' else 'shareholder_register_filing_session_factory'):sessions})

@app.middleware('http')
async def observe(request:Request,call_next):
    observed=None
    if not request.url.path.startswith('/__proof/'):
        body=await request.body()
        observed={'method':request.method,'path':request.url.path,'authorization':request.headers.get('authorization'),'requestId':request.headers.get('x-request-id'),'body':json.loads(body) if body else None}
        sessions.requests.append(observed)
    response=await call_next(request)
    if observed is not None:observed.update(status=response.status_code,responseRequestId=response.headers.get('x-request-id'),cacheControl=response.headers.get('cache-control'))
    return response

@app.post('/__proof/reset')
async def reset(request:Request):sessions.reset((await request.json()).get('mode','normal'));return {'ok':True}

@app.get('/__proof/state')
async def state():
    v=sessions.value
    return {'version':version,'appSource':inspect.getfile(create_app),'tokens':sessions.tokens,'requests':sessions.requests,'events':v.events,'mutationCalls':[name for name,_ in v.mutation_authority.calls],'operations':{name:asdict(value) for name,value in v.operations.operations.items()}}

# All authority bindings are existing local fakes; disallow accidental outbound sockets.
def no_outbound(*args,**kwargs):raise RuntimeError('protocol_proof_outbound_network_forbidden')
socket.socket.connect=no_outbound
uvicorn.run(app,host='127.0.0.1',port=int(port),access_log=False,log_level='warning')
