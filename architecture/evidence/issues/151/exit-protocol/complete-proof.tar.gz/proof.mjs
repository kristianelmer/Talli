import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const root=process.env.PROOF_ROOT;
const bases={old:`http://127.0.0.1:${process.env.OLD_PORT}`,new:`http://127.0.0.1:${process.env.NEW_PORT}`};
const nativeFetch=globalThis.fetch;
const outgoing=[];
globalThis.fetch=async(input,options)=>{
 const url=new URL(typeof input==='string'?input:input.url??input);
 assert.ok(Object.values(bases).includes(url.origin),'external network prohibited');
 if(!url.pathname.startsWith('/__proof/'))outgoing.push({url:url.href,method:options?.method,cache:options?.cache});
 return nativeFetch(input,options);
};
const load=(version,path)=>import(pathToFileURL(`${root}/${version}/${path}`).href);
const clients={old:await load('old','packages/talli-api-client/src/index.ts'),new:await load('new','packages/talli-api-client/src/index.ts')};
const transports={old:await load('old','apps/web/features/legacy-rf1086/transport.ts'),new:await load('new','apps/web/features/shareholder-register-filing/transport.ts')};
const OWNER='60000000-0000-4000-8000-000000000006', COMPANY='70000000-0000-4000-8000-000000000007', APPROVAL='80000000-0000-4000-8000-000000000008', ENTITLEMENT='90000000-0000-4000-8000-000000000009', PREVIEW='a0000000-0000-4000-8000-00000000000a', SUBMISSION='c0000000-0000-4000-8000-00000000000c';
const token='local-owner';
const report={node:process.version,sourceManifest:'source-manifest.json',results:[],limitations:['Exact pinned transports/generated clients and real FastAPI routes/coordinators over loopback HTTP.','Existing in-memory CoordinatorSession authority/persistence/billing/identity fakes; no DB or actual identity/provider integration.','Actions are exact AST-extracted pinned function bodies, transpiled with repo TypeScript and injected boundary dependencies, not full Next hydration.','No old preparation UI continuity is asserted after writer cutover.']};
async function reset(server,mode='normal'){process.env.TALLI_BACKEND_URL=bases[server];await fetch(`${bases[server]}/__proof/reset`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode})});}
async function state(server){return (await fetch(`${bases[server]}/__proof/state`)).json();}
function record(name,evidence){report.results.push({name,passed:true,evidence});console.log(`PASS ${name}`);}
function checkWire(value,path,body,status=200){assert.equal(value.method,'POST');assert.equal(value.path,path);assert.deepEqual(value.body,body);assert.equal(value.authorization,'Bearer local-owner');assert.equal(value.status,status);assert.equal(value.requestId,null);assert.match(value.responseRequestId,/^[0-9a-f-]{36}$/);assert.equal(value.cacheControl,'no-store');}
async function apiError(promise,version,status,code){let caught;try{await promise;}catch(e){caught=e;}assert.ok(caught instanceof clients[version].TalliApiError,`expected ${version} TalliApiError, got ${caught}`);assert.equal(caught.status,status);if(code)assert.equal(caught.problem?.code,code);return {status:caught.status,code:caught.problem?.code??null};}
try {
for(const [client,server] of [['old','new'],['new','old']]){
 await reset(server);
 assert.deepEqual(await transports[client].sendApprovedRf1086ThroughApi(token,APPROVAL),{submissionId:SUBMISSION});
 let first=await state(server);
 checkWire(first.requests[0],'/api/v1/legacy-rf1086/production-filings',{approvalId:APPROVAL});
 assert.deepEqual(first.tokens,[token]);
 assert.deepEqual(first.events,['configuration','approval','fresh_mfa','preview','billing_snapshot','billing_entitlement','company','connection','mutation_token','begin','operation_journal','claim','reference','feedback_journal','release','discard']);
 assert.deepEqual(first.mutationCalls,['main','sub','sub','confirm','list']);
 assert.equal(Object.keys(first.operations).length,5);
 assert.deepEqual(await transports[client].sendApprovedRf1086ThroughApi(token,APPROVAL),{submissionId:SUBMISSION});
 let repeated=await state(server);
 assert.deepEqual(repeated.operations,first.operations);assert.deepEqual(repeated.mutationCalls,first.mutationCalls);
 record(`${client} transport -> ${server} backend: Send wire, token-before-begin, same five operation identities on retry`,{first,repeated});
 await reset(server);
 assert.deepEqual(await transports[client].reconcileRf1086ThroughApi(token,SUBMISSION),{state:'accepted',errorCode:null,requiresManualRetry:false});
 let recovered=await state(server);
 checkWire(recovered.requests[0],'/api/v1/legacy-rf1086/feedback-reconciliations',{submissionId:SUBMISSION});
 assert.deepEqual(recovered.mutationCalls,[]);assert.deepEqual(recovered.operations,{});
 assert.equal(recovered.events.includes('begin'),false);assert.equal(recovered.events.includes('fresh_mfa'),false);
 assert.ok(recovered.events.indexOf('claim')<recovered.events.indexOf('reference'));
 assert.ok(recovered.events.indexOf('reference')<recovered.events.indexOf('recovery_token'));
 record(`${client} transport -> ${server} backend: compatible read-only recovery`,recovered);
 await reset(server,'unknown');
 let error1=await apiError(transports[client].sendApprovedRf1086ThroughApi(token,APPROVAL),client,503,'send_unavailable');
 let unknown1=await state(server);
 let error2=await apiError(transports[client].sendApprovedRf1086ThroughApi(token,APPROVAL),client,503,'send_unavailable');
 let unknown2=await state(server);
 assert.deepEqual(unknown2.mutationCalls,['main']);assert.deepEqual(unknown2.operations,unknown1.operations);
 assert.equal(Object.keys(unknown2.operations).length,1);assert.equal(Object.values(unknown2.operations)[0].state,'unknown');
 record(`${client} transport -> ${server} backend: unknown outcome never blindly reposted`,{error1,error2,unknown1,unknown2});
 await reset(server,'token_failure');
 const tokenFailure=await apiError(transports[client].sendApprovedRf1086ThroughApi(token,APPROVAL),client,503,'send_unavailable');
 const failed=await state(server);assert.equal(failed.events.includes('begin'),false);assert.deepEqual(failed.mutationCalls,[]);assert.deepEqual(failed.operations,{});
 record(`${client} transport -> ${server} backend: token failure precedes every mutation`,{tokenFailure,state:failed});
 await reset(server);
 const authFailure=await apiError(transports[client].sendApprovedRf1086ThroughApi('wrong-owner',APPROVAL),client,401,'authentication_required');
 const denied=await state(server);assert.deepEqual(denied.events,[]);assert.deepEqual(denied.mutationCalls,[]);assert.deepEqual(denied.operations,{});
 record(`${client} transport -> ${server} backend: invalid bearer cannot begin`,{authFailure,state:denied});
 await reset(server);
 const suppliedRequestId=`rf151-${client}-to-${server}`;
 assert.deepEqual(await clients[client].createTalliApiClient({baseUrl:bases[server],headers:{Authorization:`Bearer ${token}`}}).legacyRf1086ReconcileFeedback({submissionId:SUBMISSION},{requestId:suppliedRequestId}),{state:'accepted',errorCode:null,requiresManualRetry:false});
 const correlated=await state(server);assert.equal(correlated.requests[0].requestId,suppliedRequestId);assert.equal(correlated.requests[0].responseRequestId,suppliedRequestId);
 record(`${client} generated client -> ${server} backend: explicit correlation preserved`,correlated.requests);
}
const current=transports.new;
const calls=[
 ['findRf1086Preview',[token,PREVIEW]],
 ['acknowledgeOwnedRf1086Comment',[token,PREVIEW]],
 ['loadRf1086Workspaces',[token,[COMPANY],2025]],
 ['loadRf1086ArchiveSource',[token,COMPANY,2025]],
 ['generateRf1086PreviewThroughApi',[token,{companyId:COMPANY,openingSnapshotId:PREVIEW}]],
 ['recordRf1086OverrideThroughApi',[token,{previewId:PREVIEW,fieldTarget:'company.name',newValue:'After',oldValue:'Before',ownerConfirmed:true,reason:'Documented reason',riskLevel:'warning'}]],
 ['addRf1086ReviewCommentThroughApi',[token,{previewId:PREVIEW,body:'Review note',severity:'advisory'}]],
 ['confirmRf1086SimulationThroughApi',[token,{previewId:PREVIEW,authorityConfirmed:true,previewConfirmed:true}]],
 ['confirmRf1086PermissionThroughApi',[token,{companyId:COMPANY,productionEnabled:true}]],
 ['recordRf1086TestEvidenceThroughApi',[token,{companyId:COMPANY,environment:'test',status:'accepted',testReference:'local-test',feedbackSummary:'ok',archiveReference:null,evidenceUrl:null,payloadHash:null,receiptReference:null}]],
 ['approveRf1086ProductionThroughApi',[token,{previewId:PREVIEW,entitlementId:ENTITLEMENT,realFilingConfirmed:true}]],
];
for(const [name,args] of calls){
 await reset('old');const before=outgoing.length;
 const error=await apiError(current[name](...args),'new',404);
 assert.notEqual(error.code,'SHAREHOLDER_REGISTER_FILING_NOT_FOUND');
 const observed=await state('old');assert.equal(observed.requests.length,1);assert.equal(outgoing.length-before,1);
 assert.deepEqual(observed.tokens,[]);assert.deepEqual(observed.events,[]);assert.deepEqual(observed.mutationCalls,[]);assert.deepEqual(observed.operations,{});
 record(`new ${name} -> predecessor missing route: typed error, no ownership fallback or backend ports`,{error,state:observed});
}
const ts=createRequire(`${process.env.REPO_ROOT}/package.json`)('typescript');
const actionPath=`${root}/new/apps/web/app/actions.ts`,source=readFileSync(actionPath,'utf8');
const parsed=ts.createSourceFile('actions.ts',source,ts.ScriptTarget.Latest,true);
for(const name of ['addFilingOverride','addFilingReviewComment','acknowledgeFilingReviewComment','confirmSimulatedRf1086Submission','confirmAuthorityPermission','recordAuthorityTestEvidence']){
 await reset('old');const effects=[],redirects=[];const sentinel=Symbol('redirect');
 const form=new FormData();
 for(const [k,v] of Object.entries({companyId:COMPANY,previewId:PREVIEW,commentId:PREVIEW,ownerConfirmed:'on',authorityConfirmed:'on',previewConfirmed:'on',fieldTarget:'company.name',newValue:'After',oldValue:'Before',reason:'Documented reason',riskLevel:'warning',severity:'advisory',body:'Review note',obligation:'aksjonaerregisteroppgaven',productionEnabled:'on',environment:'test',status:'accepted',testReference:'local-test'}))form.set(k,v);
 const dependencies={...current,
  hasSupabaseEnv:()=>true,
  createSupabaseServerClient:async()=>({auth:{getUser:async()=>({data:{user:{id:OWNER}}})},from:(table)=>{effects.push(`public:${table}`);throw Error('Forbidden public read/write/audit port');}}),
  formString:(data,key)=>data.get(key)??'',getCurrentSessionAccessToken:async()=>token,
  presentRf1086Preview:value=>value,validateFilingOverride:value=>value,assertAdvisoryCanBeAcknowledged:()=>{},
  requireSensitiveActionStepUp:async()=>effects.push('local-step-up'),validateAuthorityObligation:value=>value,
  buildAuthorityTestRun:()=>({test_reference:'local-test',feedback_summary:'ok',receipt_reference:null,archive_reference:null,evidence_url:null,payload_hash:null}),
  revalidatePath:()=>effects.push('revalidate'),returnTarget:()=>'/workspace',
  redirect:(url)=>{redirects.push(url);throw sentinel;},
 };
 const node=parsed.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name.text===name);assert.ok(node,name);
 const text=node.getText(parsed);
 const code=ts.transpileModule(text.replace('export async','async'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
 const action=new Function(...Object.keys(dependencies),`${code}\nreturn ${name};`)(...Object.values(dependencies));
 await assert.rejects(action(form),e=>e===sentinel);
 assert.equal(redirects.length,1);assert.match(redirects[0],/^\/workspace\?error=/);
 assert.equal(effects.some(e=>e!=='local-step-up'),false);
 const observed=await state('old');assert.equal(observed.requests.length,1);assert.equal(observed.requests[0].status,404);
 assert.deepEqual(observed.tokens,[]);assert.deepEqual(observed.events,[]);assert.deepEqual(observed.mutationCalls,[]);
 record(`current action ${name} -> predecessor: no public read/write/audit or success redirect after missing-route error`,{sourceSha256:createHash('sha256').update(text).digest('hex'),effects,redirects,state:observed});
}
assert.ok(outgoing.every(call=>call.cache==='no-store'));
report.passed=true;report.total=report.results.length;
console.log(`PASS total ${report.total}; all ${outgoing.length} real API fetches used no-store; no external calls.`);
} catch(error){report.passed=false;report.failure={message:error.message,stack:error.stack};console.error(error);process.exitCode=1;}
finally {writeFileSync(`${root}/results.json`,JSON.stringify(report,null,2)+'\n');}
